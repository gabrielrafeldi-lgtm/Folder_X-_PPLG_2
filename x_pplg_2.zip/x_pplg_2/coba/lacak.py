from flask import Flask, render_template_string, request, jsonify
import requests

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Address Tracker</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }
        .input-group {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        input {
            flex: 1;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        input:focus {
            outline: none;
            border-color: #667eea;
        }
        button {
            padding: 15px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: transform 0.2s;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        .result {
            display: none;
            margin-top: 30px;
            padding: 25px;
            background: #f8f9fa;
            border-radius: 15px;
            border-left: 5px solid #667eea;
        }
        .result.show { display: block; animation: slideIn 0.5s ease; }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-top: 15px;
        }
        .info-item {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .info-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .info-value {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-top: 5px;
        }
        .map-link {
            display: block;
            margin-top: 20px;
            padding: 15px;
            background: #28a745;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 10px;
            font-weight: bold;
        }
        .error {
            background: #dc3545;
            color: white;
            padding: 15px;
            border-radius: 10px;
            margin-top: 20px;
            display: none;
        }
        .ip-display {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            color: #667eea;
            margin: 20px 0;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌍 IP Address Tracker</h1>
        <p class="subtitle">Lacak lokasi berdasarkan IP Address</p>
        
        <div class="input-group">
            <input type="text" id="ipInput" placeholder="Contoh: 8.8.8.8 atau kosongkan untuk IP sendiri">
            <button onclick="trackIP()">Lacak</button>
        </div>
        
        <div class="error" id="errorBox"></div>
        
        <div class="result" id="resultBox">
            <div class="ip-display" id="ipDisplay"></div>
            
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Negara</div>
                    <div class="info-value" id="country"></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Provinsi</div>
                    <div class="info-value" id="region"></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Kota</div>
                    <div class="info-value" id="city"></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Kode Pos</div>
                    <div class="info-value" id="zip"></div>
                </div>
                <div class="info-item">
                    <div class="info-label">ISP/Provider</div>
                    <div class="info-value" id="isp"></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Koordinat</div>
                    <div class="info-value" id="coords"></div>
                </div>
            </div>
            
            <a id="mapLink" href="#" target="_blank" class="map-link">📍 Lihat di Google Maps</a>
        </div>
    </div>

    <script>
        async function trackIP() {
            const ip = document.getElementById('ipInput').value;
            const errorBox = document.getElementById('errorBox');
            const resultBox = document.getElementById('resultBox');
            
            errorBox.style.display = 'none';
            resultBox.classList.remove('show');
            
            try {
                const response = await fetch('/track', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ip: ip})
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('ipDisplay').textContent = data.ip;
                    document.getElementById('country').textContent = data.country;
                    document.getElementById('region').textContent = data.region;
                    document.getElementById('city').textContent = data.city;
                    document.getElementById('zip').textContent = data.zip || '-';
                    document.getElementById('isp').textContent = data.isp;
                    document.getElementById('coords').textContent = `${data.lat}, ${data.lon}`;
                    document.getElementById('mapLink').href = 
                        `https://www.google.com/maps?q=${data.lat},${data.lon}`;
                    
                    resultBox.classList.add('show');
                } else {
                    errorBox.textContent = 'Error: ' + data.error;
                    errorBox.style.display = 'block';
                }
            } catch (err) {
                errorBox.textContent = 'Gagal menghubungi server';
                errorBox.style.display = 'block';
            }
        }
        
        // Enter key support
        document.getElementById('ipInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') trackIP();
        });
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/track', methods=['POST'])
def track():
    data = request.get_json()
    ip = data.get('ip', '').strip()
    
    # Validasi IP sederhana
    if ip and not validate_ip(ip):
        return jsonify({'success': False, 'error': 'Format IP tidak valid'})
    
    try:
        url = f"http://ip-api.com/json/{ip if ip else ''}"
        response = requests.get(url, timeout=10)
        result = response.json()
        
        if result.get('status') == 'success':
            return jsonify({
                'success': True,
                'ip': result.get('query'),
                'country': result.get('country'),
                'region': result.get('regionName'),
                'city': result.get('city'),
                'zip': result.get('zip'),
                'lat': result.get('lat'),
                'lon': result.get('lon'),
                'isp': result.get('isp'),
                'timezone': result.get('timezone')
            })
        else:
            return jsonify({
                'success': False, 
                'error': result.get('message', 'Gagal melacak IP')
            })
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def validate_ip(ip):
    """Validasi format IP sederhana"""
    parts = ip.split('.')
    if len(parts) != 4:
        return False
    for part in parts:
        if not part.isdigit() or not 0 <= int(part) <= 255:
            return False
    return True

if __name__ == '__main__':
    app.run(debug=True, port=5000)